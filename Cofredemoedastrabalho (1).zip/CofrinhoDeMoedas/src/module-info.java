/**
 * 
 */
/**
 * 
 */
module CofrinhoDeMoedas {
}