package br.cofrinho;

public class Dolar extends Moeda {

    public Dolar(double quantia) {
        super(quantia);
    }

    // Converte o valor do dólar para reais
    @Override
    public double converterParaReais() {
        return quantia * 6; // Exemplo de taxa fictícia
    }
    //Soma e retorno do que foi pedido para exibir no console
    @Override
    public String toString() {
        return "Dólar: " + quantia;
    }
}
