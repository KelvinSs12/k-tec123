package br.cofrinho;

public abstract class Moeda {
    protected double quantia;

    public Moeda(double quantia) {
        this.quantia = quantia;
    }

    // Faz a conversão para reais
    public abstract double converterParaReais();

    @Override
    public abstract String toString();

    // Compara se duas moedas têm o mesmo valor
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Moeda moeda = (Moeda) obj;
        return Double.compare(moeda.quantia, quantia) == 0;
    }

    // Garante consistência com o equals
    @Override
    public int hashCode() {
        return Double.hashCode(quantia);
    }
}
