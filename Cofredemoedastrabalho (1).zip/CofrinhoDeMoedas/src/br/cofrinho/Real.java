package br.cofrinho;

public class Real extends Moeda {

    public Real(double quantia) {
        super(quantia);
    }

    // Retorna o valor em reais (sem conversão)
    @Override
    public double converterParaReais() {
        return quantia;
    }
    //Soma e retorno do que foi pedido para exibir no console
    @Override
    public String toString() {
        return "Real: " + quantia;
    }
}
