package br.cofrinho;

public class DolarAustraliano extends Moeda {

	public DolarAustraliano(double quantia) {
        super(quantia);
    }
	// Converte o valor do dólar da autralia para reais
    @Override
    public double converterParaReais() {
        return quantia * 3; // Taxa fictícia
    }
  //Soma e retorno do que foi pedido para exibir no console
    @Override
    public String toString() {
        return "Dólar Australiano: " + quantia;
    }
	
}

