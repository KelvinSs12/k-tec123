package br.cofrinho;

public class Euro extends Moeda {

    public Euro(double quantia) {
        super(quantia);
    }

    // Converte o valor do Euro para reais
    @Override
    public double converterParaReais() {
        return quantia * 7; // Exemplo de taxa fictícia
    }
    //Soma e retorno do que foi pedido para exibir no console
    @Override
    public String toString() {
        return "Euro: " + quantia;
    }
}
