package br.cofrinho;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        // Inicializa o cofrinho onde as moedas serão armazenadas
        Cofrinho cofre = new Cofrinho();
        Scanner input = new Scanner(System.in);

        System.out.println("Bem-vindo ao seu Cofrinho Virtual!");

        while (true) {
            // Exibe o menu principal
            System.out.println("\n----- MENU PRINCIPAL -----");
            System.out.println("1 - Guardar Moeda");
            System.out.println("2 - Remover Moeda");
            System.out.println("3 - Mostrar Moedas");
            System.out.println("4 - Calcular Total em Reais");
            System.out.println("5 - Sair");
            System.out.print("Escolha uma opção: ");

            if (!input.hasNextInt()) {
                System.out.println("Entrada inválida! Por favor, digite um número entre 1 e 5.");
                input.next(); // Limpa a entrada
                continue;
            }

            int opcao = input.nextInt();

            switch (opcao) {
                case 1 -> guardarMoeda(cofre, input);
                case 2 -> removerMoeda(cofre, input);
                case 3 -> cofre.listarMoedas();
                case 4 -> System.out.printf("Total acumulado em reais: R$ %.2f%n", cofre.calcularTotalConvertido());
                case 5 -> {
                    System.out.println("Obrigado por usar o Cofrinho! Até a próxima.");
                    input.close();
                    return;
                }
                default -> System.out.println("Opção inválida! Escolha um número entre 1 e 5.");
            }
        }
    }

    // Função para guardar moeda
    private static void guardarMoeda(Cofrinho cofre, Scanner input) {
        System.out.println("\nSelecione o tipo de moeda:");
        System.out.println("1 - Real");
        System.out.println("2 - Dólar");
        System.out.println("3 - Euro");
        System.out.println("4 - Dólar Australiano");

        if (!input.hasNextInt()) {
            System.out.println("Entrada inválida! Escolha um número entre 1 e 4.");
            input.next();
            return;
        }

        int tipoMoeda = input.nextInt();

        System.out.print("Digite o valor da moeda: ");
        if (!input.hasNextDouble()) {
            System.out.println("Valor inválido! Digite um número decimal.");
            input.next();
            return;
        }

        double valor = input.nextDouble();

        Moeda novaMoeda = switch (tipoMoeda) {
            case 1 -> new Real(valor);
            case 2 -> new Dolar(valor);
            case 3 -> new Euro(valor);
            case 4 -> new DolarAustraliano(valor);
            default -> {
                System.out.println("Tipo de moeda inválido!");
                yield null;
            }
        };

        if (novaMoeda != null) {
            cofre.guardarMoeda(novaMoeda);
            System.out.println("Moeda adicionada com sucesso!");
        }
    }

    // Função para remover moeda
    private static void removerMoeda(Cofrinho cofre, Scanner input) {
        System.out.println("\nSelecione o tipo de moeda para remover:");
        System.out.println("1 - Real");
        System.out.println("2 - Dólar");
        System.out.println("3 - Euro");
        System.out.println("4 - Dólar Australiano");

        if (!input.hasNextInt()) {
            System.out.println("Entrada inválida! Escolha um número entre 1 e 4.");
            input.next();
            return;
        }

        int tipoRemover = input.nextInt();

        System.out.print("Digite o valor da moeda a remover: ");
        if (!input.hasNextDouble()) {
            System.out.println("Valor inválido! Digite um número decimal.");
            input.next();
            return;
        }

        double removerValor = input.nextDouble();

        Moeda moedaRemover = switch (tipoRemover) {
            case 1 -> new Real(removerValor);
            case 2 -> new Dolar(removerValor);
            case 3 -> new Euro(removerValor);
            case 4 -> new DolarAustraliano(removerValor);
            default -> {
                System.out.println("Tipo de moeda inválido!");
                yield null;
            }
        };

        if (moedaRemover != null) {
            cofre.removerMoeda(moedaRemover);
        }
    }
}
