package br.cofrinho;

import java.util.ArrayList;

public class Cofrinho {
    private final ArrayList<Moeda> moedasGuardadas;

    public Cofrinho() {
        moedasGuardadas = new ArrayList<>();
    }

    public void guardarMoeda(Moeda moeda) {
        moedasGuardadas.add(moeda);
        System.out.println("✅ Moeda adicionada ao cofrinho!");
    }

    public void removerMoeda(Moeda moeda) {
        if (moedasGuardadas.remove(moeda)) {
            System.out.println("✅ Moeda removida com sucesso!");
        } else {
            System.out.println("⚠️ A moeda informada não foi encontrada.");
        }
    }

    public void listarMoedas() {
        if (moedasGuardadas.isEmpty()) {
            System.out.println("⚠️ O cofrinho está vazio.");
        } else {
            System.out.println("💰 Moedas guardadas:");
            moedasGuardadas.forEach(System.out::println);
        }
    }

    public double calcularTotalConvertido() {
        return moedasGuardadas.stream()
                .mapToDouble(Moeda::converterParaReais)
                .sum();
    }
}
